package json;

public class Product {
        public int id;
        public String description;
        public double price;
    public Product(int id, String description, double price){
        this.id=id;
        this.description=description;
        this.price=price;
    }
}
